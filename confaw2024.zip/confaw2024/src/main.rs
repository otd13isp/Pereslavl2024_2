// Actix Web — веб-фреймворк для Rust
use actix_web::{get, post, web, App, HttpResponse, HttpServer, Responder};
// обеспечивает поиск в строках совпадений с регулярным выражением
use regex::Regex;
// Serde предоставляет реализации десериализации для многих типов примитивов и стандартных библиотек Rust
use serde::Deserialize;
// модуль содержит базовые методы для управления содержимым локальной файловой системы
use std::fs;
// для создания нового потока необходимо вызвать функцию thread::spawn
use std::thread;

/* ****************************************************** */
// запуск сервера
#[actix_web::main]
// std::io::Result<()> - специализированный тип результата для операций ввода-вывода
async fn main() -> std::io::Result<()> {
    HttpServer::new(|| App::new().service(hello).service(search))
        .bind(("127.0.0.1", 8080))?
        .run()
        .await
}

/* ****************************************************** */
// обработка запросов GET
#[get("/")]
async fn hello() -> impl Responder {
    let contents = fs::read_to_string("public/html/index.html")
        .expect("Should have been able to read the file");
    HttpResponse::Ok().body(contents)
}

/* ****************************************************** */
fn search_in_file(filename: String, query_l: String) -> Vec<String> {
    // считываение содержимого файла
    let contents = fs::read_to_string("public/html/".to_owned() + &filename)
        .expect("Что-то пошло не так при чтении файла");
    // создание вектора для вывода строк, содержащих образец
    let mut result = Vec::new();
    // проход по тексту в файле и поиск совпадений построчно
    for line in contents.lines() {
        let re = Regex::new(&query_l).unwrap();
        if re.is_match(&line) == true {
            let s = line.split("####").last().unwrap();
            result.push(s.to_string());
        }
    }
    //для отладки использовать команду println!("Найдено в файле: {:?}", result);
    result
}

/* ****************************************************** */
// использование структуры для считывания параметров
#[derive(Deserialize)]
struct FormData {
    search: String,
}
// обработка запросов POST
#[post("/search")]
async fn search(form: web::Form<FormData>) -> impl Responder {
    let search = format!("{}", form.search);
    let search = search.to_lowercase();
    // предполагаем, что для строки поиска была проведена лемматизация
    // удаляем пробелы справа и слева строки
    let search = search.trim();
    // заменяем несколько пробелов на регулярное выражение
    let re = Regex::new(r"\s+").unwrap();
    let search = re.replace_all(&search, "( | .* )");
    // добавляем регулярные выражения в начало и конец строки поиска
    let search = format!("{}{}{}", "(^|.* )", search, "( .*####|####)");
    println!("search={}", search);
    // определяем вектор file_names, состоящий из строк
    let file_names = vec!["file1.txt".to_string(), "file2.txt".to_string()];
    let mut my_threads = vec![];
    for file_name in file_names {
        let search_aux = search.clone();
	    // создаем потоки, передавая в них имена файлов из вектора file_names
        my_threads.push(thread::spawn(move || search_in_file(file_name, search_aux)));
    }
    let results = my_threads.into_iter().map(|handle| handle.join().unwrap());
    // формирование результата
    let mut my_out = String::new();
    for v in results {
        for mut s in v {
            // println!("Найденная строка: {}", s);
            s.push_str("<br>");
            my_out.push_str(&s);
        }
    }
    HttpResponse::Ok().body(my_out)
}
